<?php
include('db.php');

// Initialize response
$response = [
    "userCount" => 0,
    "quizCount" => 0,
    "rewardCount" => 0
];

// Fetch total users
$sql_users = "SELECT COUNT(*) AS total FROM users";
$result_users = $conn->query($sql_users);
if ($result_users && $row = $result_users->fetch_assoc()) {
    $response['userCount'] = $row['total'];
}

// Fetch total quizzes
$sql_quizzes = "SELECT COUNT(*) AS total FROM quizzes";
$result_quizzes = $conn->query($sql_quizzes);
if ($result_quizzes && $row = $result_quizzes->fetch_assoc()) {
    $response['quizCount'] = $row['total'];
}

// Fetch total rewards
$sql_rewards = "SELECT COUNT(*) AS total FROM reward";
$result_rewards = $conn->query($sql_rewards);
if ($result_rewards && $row = $result_rewards->fetch_assoc()) {
    $response['rewardCount'] = $row['total'];
}

// Return the response in JSON format
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
