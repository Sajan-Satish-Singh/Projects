<?php
include('db.php'); 

if (isset($_POST['add_user'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql_add_user = "INSERT INTO users (name, email) VALUES ('$name', '$email')";
    if ($conn->query($sql_add_user) === TRUE) {
        header('Location: manage_users.php');
        exit();
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New User</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #121212;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #f1f1f1;
        }

        header {
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            color: rgb(0, 0, 0);
            padding: 20px;
            text-align: center;
            font-size: 2em;
            position: relative;
            font-family: 'Georgia', serif;
            letter-spacing: 1px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: #2a2a2a;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #f1f1f1;
            font-size: 2.5em;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #ff6a00;
        }

        input[type="text"], 
        input[type="email"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 2px solid #ccc;
            border-radius: 50px;
            font-size: 16px;
            color: #333;
            transition: border 0.3s ease;
        }

        input[type="text"]:focus, 
        input[type="email"]:focus {
            border-color: #ff6a00;
            outline: none;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }

        .btn {
            display: inline-block;
            background-color: #ff6a00;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            flex: 1;
            margin: 0 10px;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #e65c00;
        }

        .btn.back {
            background-color: #6c757d;
        }

        .btn.back:hover {
            background-color: #5a6268;
        }

        @media (max-width: 768px) {
            header {
                font-size: 1.5em;
                padding: 15px;
            }

            .container {
                width: 80%;
                padding: 20px;
            }

            h1 {
                font-size: 2em;
            }

            .button-container {
                flex-direction: column;
                align-items: center;
            }

            .btn {
                margin: 10px 0;
                width: 100%;
            }
        }

        @media (max-width: 480px) {
            header {
                font-size: 1.2em;
                padding: 10px;
            }

            .container {
                width: 90%;
                padding: 15px;
            }

            h1 {
                font-size: 1.8em;
            }

            .btn {
                font-size: 14px;
                padding: 10px 15px;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>Add New User</h1>
    </header>

    <div class="container">
        <form action="add_user.php" method="POST">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <div class="button-container">
                <a href="manage_users.php" class="btn back">Back to Manage Users</a>
                <button type="submit" class="btn" name="add_user">Add User</button>
            </div>
        </form>
    </div>
</body>

</html>

<?php
$conn->close();
?>