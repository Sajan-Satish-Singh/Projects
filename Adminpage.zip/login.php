<?php
session_start();

// Check if the user is already logged in, redirect to dashboard if true
if (isset($_SESSION['username'])) {
    header("Location: dashboard.html");
    exit();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Valid credentials
    $valid_username = 'user';
    $valid_password = '123';

    // Validate login credentials
    if ($username == $valid_username && $password == $valid_password) {
        $_SESSION['username'] = $username; // Set session variable
        header("Location: dashboard.html"); // Redirect to dashboard.html
        exit();
    } else {
        $error_message = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212;
            color: #f1f1f1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: #2c2c2c;
            padding: 40px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            border-radius: 8px;
            width: 300px;
            text-align: center;
            position: relative;
        }
        .login-container h2 {
            margin-bottom: 20px;
            font-size: 1.8em;
            color: #ff6a00;
        }
        .login-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .login-container button {
            width: 100%;
            padding: 12px;
            background-color: #ff6a00;
            color: white;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            font-size: 1.1em;
            text-transform: uppercase;
            transition: background 0.3s ease, transform 0.2s ease;
        }
        .login-container button:hover {
            background-color: #e65c00;
            transform: scale(1.05);
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .login-header {
            position: absolute;
            top: -30px;
            left: 0;
            right: 0;
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            color: #000;
            padding: 15px;
            font-size: 1.2em;
            font-family: 'Georgia', serif;
            letter-spacing: 1px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        }
    </style>
</head>
<body>

    <div class="login-container">
        <div class="login-header">
            <h1>Login</h1>
        </div>

        <?php
        // Display error message if credentials are incorrect
        if (isset($error_message)) {
            echo "<p class='error'>$error_message</p>";
        }
        ?>

        <form method="POST" action="login.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>

            <button type="submit">Login</button>
        </form>
    </div>

</body>
</html>
