<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reward_name = $_POST['reward_name'];
    $points_required = $_POST['points_required'];

    if (!empty($reward_name) && !empty($points_required)) {
        $sql_insert = "INSERT INTO reward (reward_name, points_required) VALUES (?, ?)";
        $stmt = $conn->prepare($sql_insert);
        $stmt->bind_param("si", $reward_name, $points_required);

        if ($stmt->execute()) {
            header("Location: manage_reward.php?success=Reward added successfully");
            exit();
        } else {
            $error_message = "Error: " . $stmt->error;
        }
    } else {
        $error_message = "Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Reward</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #121212;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #f1f1f1;
        }

        header {
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            color: rgb(0, 0, 0);
            padding: 20px;
            text-align: center;
            font-size: 2em;
            position: relative;
            font-family: 'Georgia', serif;
            letter-spacing: 1px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: #2a2a2a;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #f1f1f1;
            font-size: 2.5em;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #ff6a00;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 2px solid #ccc;
            border-radius: 50px;
            font-size: 16px;
            color: #333;
            transition: border 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="number"]:focus {
            border-color: #ff6a00;
            outline: none;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }

        .btn {
            display: inline-block;
            background-color: #ff6a00;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            flex: 1;
            margin: 0 10px;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #e65c00;
        }

        .btn.back {
            background-color: #6c757d;
        }

        .btn.back:hover {
            background-color: #5a6268;
        }

        @media (max-width: 768px) {
            header {
                font-size: 1.5em;
                padding: 15px;
            }

            .container {
                width: 80%;
                padding: 20px;
            }

            h1 {
                font-size: 2em;
            }

            .button-container {
                flex-direction: column;
                align-items: center;
            }

            .btn {
                margin: 10px 0;
                width: 100%;
            }
        }

        @media (max-width: 480px) {
            header {
                font-size: 1.2em;
                padding: 10px;
            }

            .container {
                width: 90%;
                padding: 15px;
            }

            h1 {
                font-size: 1.8em;
            }

            .btn {
                font-size: 14px;
                padding: 10px 15px;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>Add New Reward</h1>
    </header>

    <div class="container">
        <?php if (isset($error_message)) : ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <form action="add_reward.php" method="POST">
            <label for="reward_name">Reward Name</label>
            <input type="text" id="reward_name" name="reward_name" required>

            <label for="points_required">Points Required</label>
            <input type="number" id="points_required" name="points_required" required>

            <div class="button-container">
                <a href="manage_reward.php" class="btn back">Back to Manage Rewards</a>
                <button type="submit" class="btn" name="add_reward">Add Reward</button>
            </div>
        </form>
    </div>
</body>

</html>

<?php
$conn->close();
?>