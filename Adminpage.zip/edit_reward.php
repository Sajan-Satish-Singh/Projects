<?php
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM reward WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $reward = $result->fetch_assoc();
    } else {
        echo "<script>alert('Reward not found!'); window.location.href='manage_reward.php';</script>";
        exit();
    }

    if (isset($_POST['update_reward'])) {
        $reward_name = $_POST['reward_name'];
        $reward_points = $_POST['points_required'];

        $sql_update = "UPDATE reward 
                       SET reward_name = '$reward_name', points_required = $reward_points 
                       WHERE id = $id";
        if ($conn->query($sql_update) === TRUE) {
            echo "<script>alert('Reward updated successfully!'); window.location.href='manage_reward.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }
} else {
    echo "<script>alert('Reward ID not provided!'); window.location.href='manage_reward.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Reward</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #121212;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #f1f1f1;
        }

        header {
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            color: #000;
            padding: 20px;
            text-align: center;
            font-size: 2em;
            position: relative;
            font-family: 'Georgia', serif;
            letter-spacing: 1px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
        }

        .container {
            width: 100%;
            max-width: 600px;
            margin: 50px auto;
            background-color: #2a2a2a;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #f1f1f1;
            font-size: 2.5em;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #ff6a00;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 2px solid #ccc;
            border-radius: 50px;
            font-size: 16px;
            color: #333;
            transition: border 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="number"]:focus {
            border-color: #ff6a00;
            outline: none;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }

        .btn {
            display: inline-block;
            background-color: #ff6a00;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            flex: 1;
            margin: 0 10px;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #e65c00;
        }

        .btn.back {
            background-color: #6c757d;
        }

        .btn.back:hover {
            background-color: #5a6268;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            header {
                font-size: 1.5em;
            }

            .container {
                width: 90%;
                padding: 30px;
            }

            h1 {
                font-size: 2em;
                margin-bottom: 20px;
            }

            .button-container {
                flex-direction: column;
            }

            .btn {
                margin-bottom: 10px;
                width: 100%;
            }
        }

        @media (max-width: 480px) {
            h1 {
                font-size: 1.8em;
            }

            label {
                font-size: 14px;
            }

            input[type="text"],
            input[type="number"] {
                font-size: 14px;
            }

            .btn {
                font-size: 14px;
                padding: 10px 15px;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>Edit Reward</h1>
    </header>

    <div class="container">
        <form action="edit_reward.php?id=<?php echo $reward['id']; ?>" method="POST">
            <label for="reward_name">Reward Name</label>
            <input type="text" id="reward_name" name="reward_name" value="<?php echo $reward['reward_name']; ?>" required>

            <label for="points_required">Points Required</label>
            <input type="number" id="points_required" name="points_required" value="<?php echo $reward['points_required']; ?>" required>

            <div class="button-container">
                <a href="manage_reward.php" class="btn back">Back to Manage Rewards</a>
                <button type="submit" class="btn" name="update_reward">Update Reward</button>
            </div>
        </form>
    </div>
</body>

</html>

<?php
$conn->close();
?>
