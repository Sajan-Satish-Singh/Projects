<?php
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM quizzes WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $quiz = $result->fetch_assoc();
    } else {
        echo "<script>alert('Quiz not found!'); window.location.href='manage_quizzes.php';</script>";
        exit();
    }

    if (isset($_POST['update_quiz'])) {
        $question = $_POST['question'];
        $option_1 = $_POST['option_1'];
        $option_2 = $_POST['option_2'];
        $option_3 = $_POST['option_3'];
        $option_4 = $_POST['option_4'];
        $correct_option = $_POST['correct_option'];

        $sql_update = "UPDATE quizzes 
                       SET question = '$question', 
                           option_1 = '$option_1', 
                           option_2 = '$option_2', 
                           option_3 = '$option_3', 
                           option_4 = '$option_4', 
                           correct_option = '$correct_option' 
                       WHERE id = $id";

        if ($conn->query($sql_update) === TRUE) {
            echo "<script>alert('Quiz updated successfully!'); window.location.href='manage_quizzes.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }
} else {
    echo "<script>alert('Quiz ID not provided!'); window.location.href='manage_quizzes.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Quiz</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #121212;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #f1f1f1;
        }

        header {
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            color: rgb(0, 0, 0);
            padding: 20px;
            text-align: center;
            font-size: 2em;
            position: relative;
            font-family: 'Georgia', serif;
            letter-spacing: 1px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
        }

        .container {
            width: 100%;
            max-width: 700px;
            margin: 50px auto;
            background-color: #2a2a2a;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #f1f1f1;
            font-size: 2.5em;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #ff6a00;
        }

        textarea,
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            height: 80px;
            resize: none;
        }

        input:focus,
        textarea:focus {
            border-color: #ff6a00;
            outline: none;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .btn {
            display: inline-block;
            background-color: #ff6a00;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            flex: 1;
            margin: 0 10px;
            text-align: center;
        }

        .btn:hover {
            background-color: #e65c00;
        }

        .btn.back {
            background-color: #6c757d;
        }

        .btn.back:hover {
            background-color: #5a6268;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            header {
                font-size: 1.5em;
                padding: 15px;
            }

            .container {
                padding: 30px;
                width: 90%;
            }

            h1 {
                font-size: 2em;
            }

            .button-container {
                flex-direction: column;
                gap: 10px;
            }

            .btn {
                width: 100%;
                margin: 5px 0;
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 20px;
                width: 95%;
            }

            h1 {
                font-size: 1.8em;
            }

            label {
                font-size: 14px;
            }

            textarea,
            input[type="text"],
            input[type="number"] {
                font-size: 12px;
            }

            .btn {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>Edit Quiz</h1>
    </header>

    <div class="container">
        <form action="edit_quiz.php?id=<?php echo $quiz['id']; ?>" method="POST">
            <label for="question">Question</label>
            <textarea id="question" name="question" required><?php echo $quiz['question']; ?></textarea>

            <label for="option_1">Option 1</label>
            <input type="text" id="option_1" name="option_1" value="<?php echo $quiz['option_1']; ?>" required>

            <label for="option_2">Option 2</label>
            <input type="text" id="option_2" name="option_2" value="<?php echo $quiz['option_2']; ?>" required>

            <label for="option_3">Option 3</label>
            <input type="text" id="option_3" name="option_3" value="<?php echo $quiz['option_3']; ?>" required>

            <label for="option_4">Option 4</label>
            <input type="text" id="option_4" name="option_4" value="<?php echo $quiz['option_4']; ?>" required>

            <label for="correct_option">Correct Option (1-4)</label>
            <input type="number" id="correct_option" name="correct_option" min="1" max="4" value="<?php echo $quiz['correct_option']; ?>" required>

            <div class="button-container">
                <a href="manage_quizzes.php" class="btn back">Back to Manage Quizzes</a>
                <button type="submit" class="btn" name="update_quiz">Update Quiz</button>
            </div>
        </form>
    </div>
</body>

</html>

<?php
$conn->close();
?>
