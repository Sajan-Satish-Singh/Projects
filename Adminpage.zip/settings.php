<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <style>
        /* Base Styling */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            color: #333;
            transition: all 0.3s ease;
        }

        .luxury-container {
            max-width: 700px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h1 {
            font-size: 2.8em;
            color: #333;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .theme-buttons {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-bottom: 30px;
            flex-wrap: wrap;  /* Allow buttons to wrap on smaller screens */
        }

        .button {
            padding: 18px 30px;
            font-size: 1.3em;
            font-weight: bold;
            border-radius: 35px;
            cursor: pointer;
            width: 150px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            border: 2px solid transparent;
            transition: all 0.3s ease;
            margin: 5px;  /* Ensure spacing between buttons */
        }

        .button.dark {
            background-color: #333;
            color: white;
            border-color: #444;
        }

        .button.light {
            background-color: #f1f1f1;
            color: #333;
            border-color: #bbb;
        }

        .button.selected {
            border-color: #ff6a00;  /* Luxury accent color */
            background-color: #ff6a00;
            color: white;
        }

        .button:hover {
            transform: scale(1.05);
        }

        .back-button {
            padding: 14px 28px;
            background-color: #2c3e50;
            color: white;
            border: none;
            border-radius: 35px;
            font-size: 1.3em;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            transition: background-color 0.3s, transform 0.2s;
        }

        .back-button:hover {
            background-color: #34495e;
            transform: scale(1.05);
        }

        /* Dark Mode Styling */
        body.dark-mode {
            background-color: #121212;
            color: #f1f1f1;
        }

        .luxury-container.dark-mode {
            background-color: #1f1f1f;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }

        .button.dark.dark-mode {
            background-color: #ff6a00;
            color: white;
        }

        .button.light.dark-mode {
            background-color: #333;
            color: white;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .luxury-container {
                padding: 20px;
                margin: 20px;
            }

            h1 {
                font-size: 2em;  /* Smaller title for mobile */
            }

            .theme-buttons {
                gap: 15px;  /* Reduce space between buttons */
            }

            .button {
                width: 120px;  /* Smaller buttons on mobile */
                font-size: 1.1em;
            }

            .back-button {
                font-size: 1.1em;
            }
        }

        @media (max-width: 480px) {
            .luxury-container {
                padding: 15px;
                margin: 15px;
            }

            h1 {
                font-size: 1.6em;  /* Even smaller title */
            }

            .button {
                width: 100%;  /* Full-width buttons on very small screens */
                font-size: 1.2em;
            }

            .back-button {
                font-size: 1.2em;
                padding: 12px 24px;
            }
        }
    </style>
</head>
<body>
    <div class="luxury-container">
        <h1>Settings</h1>
        <div class="theme-buttons">
            <button class="button dark" id="darkModeBtn" onclick="setDarkMode()">Dark Mode</button>
            <button class="button light" id="lightModeBtn" onclick="setLightMode()">Light Mode</button>
        </div>
        <button class="back-button" onclick="window.location.href='dashboard.html';">Back to Dashboard</button>
    </div>

    <script>
        // Function to set Dark Mode
        function setDarkMode() {
            document.body.classList.add('dark-mode');
            document.body.classList.remove('light-mode');
            localStorage.setItem("theme", "dark-mode"); // Save preference
            updateButtonStyles();
        }

        // Function to set Light Mode
        function setLightMode() {
            document.body.classList.remove('dark-mode');
            document.body.classList.add('light-mode');
            localStorage.setItem("theme", "light-mode"); // Save preference
            updateButtonStyles();
        }

        // Update button styles to show which theme is selected
        function updateButtonStyles() {
            const darkModeBtn = document.getElementById('darkModeBtn');
            const lightModeBtn = document.getElementById('lightModeBtn');

            // Reset all button styles
            darkModeBtn.classList.remove('selected');
            lightModeBtn.classList.remove('selected');

            // Apply selected style
            if (document.body.classList.contains('dark-mode')) {
                darkModeBtn.classList.add('selected');
            } else {
                lightModeBtn.classList.add('selected');
            }
        }

        // On page load, check for saved theme and apply it
        document.addEventListener("DOMContentLoaded", () => {
            const savedTheme = localStorage.getItem("theme");
            if (savedTheme === "dark-mode") {
                setDarkMode();
            } else {
                setLightMode();
            }
        });
    </script>
</body>
</html>
