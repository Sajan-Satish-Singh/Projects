<?php
include('db.php');

$search = isset($_GET['search']) ? $_GET['search'] : '';
$sql_rewards = "SELECT * FROM reward WHERE reward_name LIKE '%$search%'";
$result_rewards = $conn->query($sql_rewards);

if (isset($_GET['delete_id'])) {
    $id_to_delete = $_GET['delete_id'];
    $delete_sql = "DELETE FROM reward WHERE id = $id_to_delete";
    if ($conn->query($delete_sql) === TRUE) {
        header('Location: manage_reward.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Rewards</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #121212;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #f1f1f1;
            overflow-x: hidden;
        }

        header {
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            color: rgb(0, 0, 0);
            padding: 20px;
            text-align: center;
            font-size: 1.8em;
            font-family: 'Georgia', serif;
            letter-spacing: 1px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
            position: relative;
            border-bottom: 2px solid #ff6a00;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            background-color: #2a2a2a;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #f1f1f1;
            font-size: 2.5em;
            margin-bottom: 30px;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }

        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            color: white;
            text-align: center;
            transition: background 0.3s ease;
        }

        .btn-info {
            background-color: #ff6a00;
        }

        .btn-info:hover {
            background-color: #e65c00;
        }

        .btn-secondary {
            background-color: #3b3b3b;
        }

        .btn-secondary:hover {
            background-color: #2e2e2e;
        }

        .form-container form {
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #ccc;
            border-radius: 50px;
            font-size: 16px;
            color: #333;
            transition: border 0.3s ease;
        }

        input[type="text"]:focus {
            border-color: #ff6a00;
        }

        button {
            padding: 12px 20px;
            border-radius: 50px;
            font-size: 16px;
            cursor: pointer;
            background-color: #ff6a00;
            border: none;
            color: white;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #e65c00;
        }

        /* Luxurious table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            background-color: #222222;
            border-radius: 10px;
        }

        table th, table td {
            padding: 14px;
            text-align: center;
            border: 1px solid #333;
            font-size: 16px;
        }

        table th {
            background-color: #ff6a00;
            color: white;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #333;
        }

        table tr:nth-child(odd) {
            background-color: #444;
        }

        table tr:hover {
            background-color: #555;
        }

        table td {
            color: #f1f1f1;
        }

        .btn-warning {
            background-color: #ffc107;
            color: black;
        }

        .btn-warning:hover {
            background-color: #e0a800;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        /* Responsive design for smaller screens */
        @media (max-width: 768px) {
            header {
                font-size: 2em;
                padding: 15px;
            }

            h1 {
                font-size: 2em;
            }

            .button-container {
                flex-direction: column;
                align-items: center;
            }

            .btn {
                width: 100%;
                margin-bottom: 10px;
            }

            .form-container form {
                flex-direction: column;
                align-items: center;
            }

            input[type="text"] {
                width: 80%;
                margin-bottom: 10px;
            }

            button {
                width: 80%;
            }

            table {
                width: 100%;
                overflow-x: auto;
                display: block;
            }

            table th, table td {
                padding: 10px;
                font-size: 14px;
            }

            /* Adjust the table layout for mobile */
            table td {
                display: table-cell;
                text-align: left;
            }

            /* Ensure each column is populated properly */
            table td .btn {
                display: inline-block;
                width: 48%;
                margin-bottom: 10px;
            }

            /* Ensure columns do not collapse on mobile */
            table th, table td {
                white-space: nowrap;
            }

            /* Separate the buttons into individual rows */
            table td .btn {
                display: block;
                width: 100%;
                margin-bottom: 10px;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>Manage Rewards</h1>
    </header>

    <div class="container">
        <!-- Buttons -->
        <div class="button-container">
            <a href="dashboard.html" class="btn btn-secondary">Back to Dashboard</a>
            <a href="add_reward.php" class="btn btn-info">Add New Reward</a>
        </div>

        <!-- Search Form -->
        <div class="form-container">
            <form action="manage_reward.php" method="GET">
                <input type="text" name="search" placeholder="Search by reward name..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <!-- Rewards Table -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Reward Name</th>
                    <th>Points Required</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result_rewards->num_rows > 0) {
                    while ($row = $result_rewards->fetch_assoc()) {
                        echo "<tr>
                                <td>" . sprintf('%03d', $row['id']) . "</td>
                                <td>" . htmlspecialchars($row['reward_name']) . "</td>
                                <td>" . htmlspecialchars($row['points_required']) . "</td>
                                <td>
                                    <a href='edit_reward.php?id=" . $row['id'] . "' class='btn btn-warning'>Edit</a>
                                    <a href='?delete_id=" . $row['id'] . "' class='btn btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' class='text-center'>No rewards found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>

<?php
$conn->close();
?>
