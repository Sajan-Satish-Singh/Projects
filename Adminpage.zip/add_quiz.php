<?php
include('db.php'); 

if (isset($_POST['add_quiz'])) {
    $question = $_POST['question'];
    $option_1 = $_POST['option_1'];
    $option_2 = $_POST['option_2'];
    $option_3 = $_POST['option_3'];
    $option_4 = $_POST['option_4'];
    $correct_option = $_POST['correct_option'];

    $sql_add_quiz = "INSERT INTO quizzes (question, option_1, option_2, option_3, option_4, correct_option)
                     VALUES ('$question', '$option_1', '$option_2', '$option_3', '$option_4', '$correct_option')";
    if ($conn->query($sql_add_quiz) === TRUE) {
        header('Location: manage_quizzes.php');
        exit();
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Quiz</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #121212;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #f1f1f1;
        }

        header {
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            color: rgb(0, 0, 0);
            padding: 20px;
            text-align: center;
            font-size: 2em;
            position: relative;
            font-family: 'Georgia', serif;
            letter-spacing: 1px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
        }

        .container {
            width: 80%;
            max-width: 800px;
            margin: 50px auto;
            background-color: #2a2a2a;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #f1f1f1;
            font-size: 2.5em;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #ff6a00;
        }

        textarea,
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            height: 80px;
            resize: none;
        }

        input:focus,
        textarea:focus {
            border-color: #ff6a00;
            outline: none;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-top: 20px;
        }

        .btn {
            display: inline-block;
            background-color: #ff6a00;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            flex: 1;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #e65c00;
        }

        .btn.back {
            background-color: #6c757d;
        }

        .btn.back:hover {
            background-color: #5a6268;
        }

        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 20px;
            }

            header {
                font-size: 1.5em;
                padding: 15px;
            }

            h1 {
                font-size: 2em;
            }

            .btn {
                padding: 10px 18px;
                font-size: 14px;
            }

            .button-container {
                flex-direction: column;
                align-items: center;
            }

            .btn {
                width: 100%;
                margin: 10px 0;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>Add New Quiz</h1>
    </header>

    <div class="container">
        <form action="add_quiz.php" method="POST">
            <label for="question">Question</label>
            <textarea id="question" name="question" required></textarea>

            <label for="option_1">Option 1</label>
            <input type="text" id="option_1" name="option_1" required>

            <label for="option_2">Option 2</label>
            <input type="text" id="option_2" name="option_2" required>

            <label for="option_3">Option 3</label>
            <input type="text" id="option_3" name="option_3" required>

            <label for="option_4">Option 4</label>
            <input type="text" id="option_4" name="option_4" required>

            <label for="correct_option">Correct Option (1-4)</label>
            <input type="number" id="correct_option" name="correct_option" min="1" max="4" required>

            <div class="button-container">
                <a href="manage_quizzes.php" class="btn back">Back to Manage Quizzes</a>
                <button type="submit" class="btn" name="add_quiz">Add Quiz</button>
            </div>
        </form>
    </div>
</body>

</html>

<?php
$conn->close();
?>